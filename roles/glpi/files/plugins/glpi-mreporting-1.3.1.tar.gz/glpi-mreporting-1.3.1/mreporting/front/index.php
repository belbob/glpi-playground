<?php
header('Location: central.php');
