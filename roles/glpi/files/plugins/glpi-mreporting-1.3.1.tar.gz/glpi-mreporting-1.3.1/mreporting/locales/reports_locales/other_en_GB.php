<?php
global $LANG;

$LANG['plugin_mreporting']['Other'] = array(
   'title' => "Other",

   'reportHbarLogs' => array(
      'title'    => "Logs distribution",
      'desc'     => "Bars",
      'category' => "Logs",
   )
);