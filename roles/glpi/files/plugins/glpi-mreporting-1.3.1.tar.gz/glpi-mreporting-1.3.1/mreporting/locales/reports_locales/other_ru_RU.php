<?php
global $LANG;

$LANG['plugin_mreporting']['Other'] = array(
   'title' => "Другое",

   'reportHbarLogs' => array(
      'title'    => "Информация по логам",
      'desc'     => "Шкалы",
      'category' => "Логи",
   ),
);