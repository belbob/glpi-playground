<?php
global $LANG;

$LANG['plugin_mreporting']['Other'] = array(
   'title' => "Autres",

   'reportHbarLogs' => array(
      'title'    => "Répartition des logs",
      'desc'     => "Barres",
      'category' => "Logs",
   )
);