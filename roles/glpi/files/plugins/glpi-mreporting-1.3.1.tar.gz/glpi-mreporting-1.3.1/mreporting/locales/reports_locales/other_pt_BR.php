<?php
global $LANG;

$LANG['plugin_mreporting']['Other']['title'] = "Outros";
$LANG['plugin_mreporting']['Other']['reportHbarLogs']['title'] = "Distribuição de logs";
$LANG['plugin_mreporting']['Other']['reportHbarLogs']['desc'] = "Barras";
$LANG['plugin_mreporting']['Other']['reportHbarLogs']['category'] = "Logs";
