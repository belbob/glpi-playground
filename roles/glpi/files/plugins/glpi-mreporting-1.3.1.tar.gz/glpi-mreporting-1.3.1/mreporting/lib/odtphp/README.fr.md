odtphp
======

Générateur de document ODT à partir de PHP

Projet initial (version 1.0.1) : http://www.odtphp.com/ (le site ne répond plus).

Le répertoire "tests" contient les exemples publiés sur ce site disparu.

Intégration des modifications de : http://vikasmahajan.wordpress.com/2010/12/09/odtphp-bug-solved/  
Résoud les bugs d'insertion d'image et d'insertion dans l'en-tête et le pied de page.

J'explore ce projet qui semble "à l'abandon" mais fait parfaitement ce dont j'ai besoin.

J'intégrerai ici mes modestes contributions et/ou exemples.
