ALTER TABLE `glpi_plugin_racks_profiles` 
   ADD `open_ticket` char(1) collate utf8_unicode_ci default NULL;