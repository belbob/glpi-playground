ALTER TABLE `glpi_plugin_racks_racks` 
   ADD `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL;