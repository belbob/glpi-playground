# domains
Plugin Domains for GLPI

Ce plugin est sur Transifex - Aidez-nous à le traduire :
https://www.transifex.com/tsmr/GLPI_domains/

This plugin is on Transifex - Help us to translate :
https://www.transifex.com/tsmr/GLPI_domains/

Ce plugin vous permet de gérer les noms de domaines de votre réseau et de les associer à des éléments de l'inventaire
> * Un système d'alertes mail permet de vérifier les noms de domaines qui vont ou qui ont expirés
> * Utilisable depuis le helpdesk
> * Peut être intégré au plugin "environment":https://github.com/InfotelGLPI/environment.


This plugin enables you to manage the domain names of your network and associate them with elements of the inventory.
> * A mailing system allow to verify already expired or soon expired domain names
> * Can be used with helpdesk
> * Can be integrated into "environment":https://github.com/InfotelGLPI/environment plugin.
