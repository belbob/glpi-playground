<?php

interface Field
{
   public static function getName();
   public static function getPrefs();
   public static function getJSFields();
}
