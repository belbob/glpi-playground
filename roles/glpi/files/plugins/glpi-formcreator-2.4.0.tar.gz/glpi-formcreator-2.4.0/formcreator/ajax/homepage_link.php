<?php
include ('../../../inc/includes.php');

echo '<li id="menu5">";
      <a href="'.$CFG_GLPI['root_doc'].'/plugins/formcreator/front/formlist.php" class="itemP">'.
      _n('Form','Forms', 2, 'formcreator').
      '</a>
      </li>';
