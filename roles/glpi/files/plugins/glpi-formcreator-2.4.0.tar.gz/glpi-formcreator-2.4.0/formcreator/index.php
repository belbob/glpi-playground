<?php
header('Location: front/form.php');
