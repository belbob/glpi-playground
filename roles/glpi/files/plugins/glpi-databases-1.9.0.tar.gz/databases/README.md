# databases
Plugin databases pour GLPI

Ce plugin est sur Transifex - Aidez-nous à le traduire :
https://www.transifex.com/tsmr/GLPI_databases/

This plugin is on Transifex - Help us to translate :
https://www.transifex.com/tsmr/GLPI_databases/

Ce plugin vous permet de gérer les bases de données de votre réseau et de les associer à des éléments de l'inventaire.
> * Inventaire des instances
> * Inventaire des scripts.
> * Utilisable depuis le helpdesk
> * Peut être intégré au plugin "environment":https://github.com/InfotelGLPI/environment.

This plugin enables you to manage the databases of your network and associate them with elements of the inventory.
> * Instances inventory
> * Scripts inventory.
> * Can be used with helpdesk
> * Can be used with "environment":https://github.com/InfotelGLPI/environment plugin
