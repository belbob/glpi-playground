# environment
Plugin environment for GLPI

Ce plugin est sur Transifex - Aidez-nous à le traduire :
https://www.transifex.com/tsmr/GLPI_environment/

This plugin is on Transifex - Help us to translate :
https://www.transifex.com/tsmr/GLPI_environment/

Ce plugin vous permet de regrouper 7 plugins dans un seul pour une meilleure visibilité du menu des plugins.
* Peut contenir :

> * Plugin "appliances":https://forge.glpi-project.org/projects/show/appliances
> * Plugin "webapplications":https://github.com/InfotelGLPI/webapplications
> * Plugin "certificates":https://github.com/InfotelGLPI/certificates
> * Plugin "accounts":https://github.com/InfotelGLPI/accounts
> * Plugin "domains":https://forge.glpi-project.org/projects/show/domains
> * Plugin "databases":https://github.com/InfotelGLPI/databases
> * Plugin "badges":https://github.com/InfotelGLPI/badges

This plugin enables you to group 7 plugins to one for more visibility of plugins menu.
* Include

> * "appliances":https://forge.glpi-project.org/projects/show/appliances Plugin
> * "webapplications":https://github.com/InfotelGLPI/webapplications Plugin
> * "certificates":https://github.com/InfotelGLPI/certificates Plugin
> * "accounts":https://github.com/InfotelGLPI/accounts Plugin
> * "domains":https://forge.glpi-project.org/projects/show/domains Plugin
> * "databases":https://github.com/InfotelGLPI/databases Plugin
> * "badges":https://github.com/InfotelGLPI/badges Plugin
