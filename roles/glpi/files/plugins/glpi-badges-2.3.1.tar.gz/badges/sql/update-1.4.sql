DROP TABLE IF EXISTS `glpi_plugin_badges_default`;
CREATE TABLE `glpi_plugin_badges_default` (
	`ID` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
	`status` INT( 11 ) NOT NULL 
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;