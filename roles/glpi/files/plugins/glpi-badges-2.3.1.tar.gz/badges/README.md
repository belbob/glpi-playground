# badges
Plugin badges pour GLPI

Ce plugin est sur Transifex - Aidez-nous à le traduire :
https://www.transifex.com/tsmr/GLPI_badges/

This plugin is on Transifex - Help us to translate :
https://www.transifex.com/tsmr/GLPI_badges/

Ce plugin vous permet de gérer les badges de votre réseau et de les associer à des éléments de l'inventaire.
> * Un système d'alertes mail permet de vérifier les badges qui vont ou qui ont expirés.
> * Utilisable depuis le helpdesk
> * Peut être intégré au plugin "environment":https://github.com/InfotelGLPI/environment.


This plugin enables you to manage your badges into your network and associate them with elements of the inventory.
> * A mailing system allow to verify already expired or soon expired badges.
> * Can be used with helpdesk
> * Can be integrated into "environment":https://github.com/InfotelGLPI/environment plugin.
